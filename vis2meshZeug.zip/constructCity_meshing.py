#!/usr/bin/env python
import os
import sys
import glob
import argparse
from os.path import join,dirname,abspath,exists,basename
import pathlib
import subprocess
import logging
import json
import re
import datetime
import shutil
import stat
import matplotlib.pyplot as plt
import numpy as np
import open3d as o3d
import trimesh as tm
import os
import pyntcloud
from pathlib import Path
import subprocess
import torch
from scipy.spatial.transform import Rotation as R
from inference import CreateCam, CreateTaskJson, RunProcess
import pandas as pd
import pointCloudOperations as pco
import constructCity_config

debug = constructCity_config.debug

pfad = constructCity_config.pfad
vhacdPath = constructCity_config.vhacdPath
partSize = constructCity_config.partSize




def create_cloud(points, rgb):
    # create ply file
    points = np.concatenate((points, rgb*255), axis=1)
    #vertices = np.array(np.ndarray.tolist(points),
    #                 dtype=[('x', 'f4'), ('y', 'f4'),
    #                        ('z', 'f4'), ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')])
    d = {'x': points[:,0].astype(np.float),'y': points[:,1].astype(np.float),'z': points[:,2].astype(np.float), 
             'red' : points[:,3].astype(np.uint8), 'green' : points[:,4].astype(np.uint8), 'blue' : points[:,5].astype(np.uint8)}
    cld = pyntcloud.PyntCloud(pd.DataFrame(data=d))
    #cld = pyntcloud.PyntCloud(pd.DataFrame(data=vertices, columns =["x", "y", "z", "red", "green", "blue"]))
    cld.to_file(pfad+"/meshing/tmp_cloud.ply")



def CopyResult(config, pfad):
    if exists(config['SUBDIR_FOLDER']+"/bundle_mesh.ply"):
        print("*************** ")
        print("*** Success *** ")
        print()
        #os.chmod(result_file, stat.S_IROTH|stat.S_IWOTH|stat.S_IXOTH)
        result_copy_file = config['SUBDIR_FOLDER']+"/bundle_mesh.ply"
        shutil.copy(result_copy_file, pfad+"/meshing/bundle_mesh.ply")
    else:
        print("*** Generation Failed *** ")


def createViews(emptyPoints):
    views = []
    maxBound = np.max(surfacePoints, axis=0)
    minBound = np.min(surfacePoints, axis=0)
    midPoint = (maxBound+minBound)/2.
    minRadius = np.linalg.norm(maxBound-midPoint)
    for theta in range(-90,90,15):
        for phi in range(0,360,15):
            distance = minRadius+0.5*minRadius*np.random.rand()
            z = distance*np.cos(np.deg2rad(phi))*np.cos(np.deg2rad(theta))  
            y = distance*np.cos(np.deg2rad(phi))*np.sin(np.deg2rad(theta))
            x = distance*np.sin(np.deg2rad(phi)) #cam view direction
            viewPoint = midPoint-np.array([x,y,z])
            view = {"width": 512,
                            "height": 512,
                            "K":[[150, 0, 128], [0, 150, 128], [0, 0, 1]]}
            r = R.from_euler('xyz', [0,-phi+45,-theta+15.], degrees=True).as_matrix()
            #r = R.from_euler('xyz', [0.,55+phi,200-theta], degrees=True).as_matrix()
            view["R"] = r.tolist()
            view["C"] = viewPoint.tolist()
            views.append(view)
    return {"imgs":views}


def tempSetup():
    os.environ["PATH"] += os.pathsep + "/home/jhm/vis2mesh/tools/bin"
    os.environ["PATH"] += os.pathsep + "/home/jhm/vis2mesh/tools/bin/OpenMVS"
    os.environ["PATH"] += os.pathsep + "/home/jhm/Documents/blender/blender2.80/blender-2.80-linux-glibc217-x86_64"
    os.environ["LD_LIBRARY_PATH"] += os.pathsep +  "/home/jhm/vis2mesh/tools/lib/OpenMVS"
    os.environ["LD_LIBRARY_PATH"] += os.pathsep +  "/home/jhm/vis2mesh/tools/lib"
    Toolset = {'vvtool': 'vvtool', 'o3d_vvcreator.py': 'o3d_vvcreator.py', 'ReconstructMesh': 'ReconstructMesh'}
    ########
    ## Config IO
    ########
    INPUT_CLOUD = os.path.abspath(pfad+"/meshing/tmp_cloud.ply")
    

    WORK_FOLDER = os.path.abspath(pfad+"/meshing/tmp_work")
    OUTPUT_FOLDER = os.path.abspath(pfad+"/meshing/tmp_output")
    SUBDIR_FOLDER = os.path.abspath(pfad+"/meshing/tmp_subdir")
    RENDER_FOLDER = os.path.abspath(pfad+"/meshing/tmp_render")
    VISCONF_FOLDER = os.path.abspath(pfad+"/meshing/tmp_viconf")
    pathlib.Path(WORK_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(SUBDIR_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(RENDER_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(VISCONF_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(OUTPUT_FOLDER).mkdir(parents=True, exist_ok=True)
    # Clean Output and conf
    for c in glob.glob(join(OUTPUT_FOLDER,'*')):
        if os.path.isdir(c):
            shutil.rmtree(c)
        else:
            os.remove(c)
    for c in glob.glob(join(VISCONF_FOLDER,'*')):
        if os.path.isdir(c):
            shutil.rmtree(c)
        else:
            os.remove(c)

    for c in glob.glob(join(RENDER_FOLDER,'*')):
        if os.path.isdir(c):
            shutil.rmtree(c)
        else:
            os.remove(c)
    return {'INPUT_CLOUD': INPUT_CLOUD,
            'INPUT_CAM': pfad+"/meshing/tmp_views.json",
            'INPUT_MESH':'',
            'INPUT_TEXMESH': '',
            'INPUT_RGBMESH':'',
            'BASE_CAM':'',
            'CAM_NAME':'tempCam',
            'TOOLCHAIN':'NET.POINT_DELAY',
            'WORK_FOLDER': WORK_FOLDER,
            'SUBDIR_FOLDER': SUBDIR_FOLDER,
            'OUTPUT_FOLDER': OUTPUT_FOLDER,
            'RENDER_FOLDER': RENDER_FOLDER,
            'VISCONF_FOLDER': VISCONF_FOLDER,
            'Toolset': Toolset,
            'imagewidth':512,
            'imageheight':512,
            'imagefocal':300,
            # 'camgenheight':args.camgenheight,
            # 'camgenoverlap':args.camgenoverlap,
            'render_shader':'POINT',
            'render_radius_k':6,
            'vis':'NET',
            'vis_arch':"CascadeNet(['PartialConvUNet(input_channels=2)', 'PartialConvUNet(input_channels=2)', 'PartialConvUNet(input_channels=3)'])",
            'vis_checkpoint':'./checkpoints/VDVNet_CascadePPP_epoch30.pth',
            'vis_gt_tolerance': 0.05,
            'vis_conf_threshold':0.5,
            'recon_param': '-d 1'}
# %%
if __name__ == '__main__':
    #clear tempPath
    for c in glob.glob(join(pfad+"/meshing/",'*')):
            if os.path.isdir(c):
                shutil.rmtree(c)
            else:
                os.remove(c)
    # load all data
    additionalSurfacePoints = np.load(pfad+"/additionalSurfacePoints.npy")
    partPoints = np.load(pfad+"/partPoints.npy")
    try:
        meshNr = np.load(pfad+"/meshNr.npy")
    except:
        meshNr = 0
    partPointsColorLearning = np.load(pfad+"/partPointsColorLearning.npy")
    partPointsColorLearningColors = np.load(pfad+"/partPointsColorLearningColors.npy")

    surfacePoints = np.concatenate((partPoints,additionalSurfacePoints), axis=0)
    create_cloud(surfacePoints, np.ones_like(surfacePoints))
    
    views = createViews(surfacePoints)
    with open(pfad+"/meshing/tmp_views.json", "w") as f:
            json.dump(views, f, indent=3)
    #run mesh recreation from point cloud
    config = tempSetup()
    config = CreateCam(config)
    config =  CreateTaskJson(config)
    config =  RunProcess(config)
    CopyResult(config, pfad)