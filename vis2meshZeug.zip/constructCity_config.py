

global debug
debug = True

global pfad
pfad = "/home/jhm/Desktop/Arbeit/ConvexNeuralVolume"
#pfad = "/files/Code/convexNeuralVolumeData"

global vhacdPath
vhacdPath = pfad+"/v-hacd/src/build/test/testVHACD"

global partSize
partSize = 25
