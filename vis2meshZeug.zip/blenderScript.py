#%%

#!/usr/bin/env python
import sys
import logging
import numpy as np
import os
import bpy
logging.info("starting")

pfad = "/home/jhm/Desktop/Arbeit/ConvexNeuralVolume"

with open(pfad+"/id.txt", 'r') as f:
      id = f.readline()

#delete default cube
try:
    active = bpy.context.active_object
    bpy.data.objects.remove(active)
except: pass

bpy.ops.object.select_all(action='DESELECT')

logging.info("reading mesh")

bpy.ops.import_mesh.ply(filepath=pfad+"/meshing/bundle_mesh.ply")
loops = np.load(pfad+"/meshing/loops.npy")
logging.info("everything loaded")
active = bpy.context.active_object

mat = bpy.data.materials.new("TexMaterial")
mat.use_nodes = True
mat.use_fake_user = True
node_tree = mat.node_tree
nodes = node_tree.nodes
mat_output = nodes['Material Output']
bsdf = nodes['Principled BSDF']

tex = nodes.new(type="ShaderNodeTexImage")
tex.image = bpy.data.images.load(pfad+"/meshing/texture.png")
node_tree.links.new(bsdf.inputs['Base Color'], tex.outputs['Color'])
tex2 = nodes.new(type="ShaderNodeTexImage")
tex2.image = bpy.data.images.load(pfad+"/meshing/texture.png")
comb = nodes.new(type="ShaderNodeRGBToBW")
multi = nodes.new(type="ShaderNodeMath")
multi.operation = 'MULTIPLY'
multi.inputs[1].default_value = 0.2

node_tree.links.new(comb.inputs['Color'], tex2.outputs['Color'])
node_tree.links.new(multi.inputs[0], comb.outputs[0])
node_tree.links.new(bsdf.inputs['Specular'], multi.outputs[0])

active.data.materials.append(mat)
bpy.context.object.active_material_index = 0
bpy.ops.object.material_slot_remove()
active.active_material = mat
bpy.context.object.active_material_index = 0


new_uv = bpy.context.active_object.data.uv_layers.new(name='NewUV')
for loop in bpy.context.active_object.data.loops:
    new_uv.data[loop.index].uv = loops[loop.index]

bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
logging.info("done texturing - saving")
bpy.ops.file.autopack_toggle()
bpy.ops.export_scene.fbx(filepath=pfad+"/textured/{}.fbx".format(id), 
                        check_existing=False, 
                        filter_glob='*.fbx', 
                        use_selection=True, 
                        global_scale=1.0, 
                        apply_unit_scale=True, 
                        apply_scale_options='FBX_SCALE_NONE', 
                        object_types={'MESH', 'OTHER'}, 
                        use_mesh_modifiers=True, 
                        use_mesh_modifiers_render=True, 
                        mesh_smooth_type='OFF', 
                        embed_textures=True, 
                        path_mode = 'COPY',
                        use_metadata=True, 
                        axis_forward='-Z', 
                        axis_up='Y')

logging.info("all saved")