# %%

import matplotlib.pyplot as plt
import numpy as np
import open3d as o3d
import trimesh as tm
import os
from pathlib import Path
import subprocess

import torch
from pointsRefine_emptyUp import meshIt_, vertexKey, makeVoxelDict, voxelGrid2Colors, voxelGrid2Voxels, fillVoxelsFurther2, fillVoxelsFurther, translateOldVoxels2New, fillVoxelMinimalDown, fillVoxelColumns, createVoxelPointsXYDict, appendEmptyPoints, loadPoints, loadEmptyPoints, checkEmptyPoints, appendPoints, appendEmptyPoints, createVoxelPointsXYDict
import voxelstuff

import voxelstuff
import pointCloudOperations
import constructCity_config

debug = constructCity_config.debug

pfad = constructCity_config.pfad
vhacdPath = constructCity_config.vhacdPath
partSize = constructCity_config.partSize
times = 0

cl = None
pcd = None


breakAll = False



#################################################################################
if __name__ == "__main__":
    import os
    if len(os.listdir(pfad+"/blocks")) == 0:
        print("creating Blocks")
        import laspy 
        with laspy.open("/out_final_resample_first_return_only.las") as input_las:
            for i, points in enumerate(input_las.chunk_iterator(100000)):
                print("points",i*100000, "to", (i+1)*100000, "of", input_las.header.point_records_count)
                intensity = np.array(points.intensity)
                pointa = np.concatenate([np.array([points.X, points.Y, points.Z]).T/100.,
                            np.array([points.red, points.green, points.blue]).T/float(2**16)],1)[intensity>10000]
                pointDicts = {}
                for p in pointa:
                    block = (int(p[0]//35),int(p[1]//35),int(p[2]//35))
                    if block in pointDicts:
                        pointDicts[block].append(p)
                    else:
                        pointDicts[block] = [p]
                for key in pointDicts.keys():
                    appendPoints(key[0],key[1],key[2], np.stack(pointDicts[key],0))

    heights = {}
    minBound__ = np.ones(3) * 9999999
    maxBound__ = np.ones(3) * 0
    for name in os.listdir(pfad+"/blocks"):
        x = int(name.split("x")[0])
        y = int(name.split("x")[1].split("y")[0])
        z = int(name.split("x")[1].split("y")[1].split("z")[0])
        if x < minBound__[0]:
            minBound__[0] = x
        if y < minBound__[1]:
            minBound__[1] = y
        if z < minBound__[2]:
            minBound__[2] = z
        if x > maxBound__[0]:
            maxBound__[0] = x
        if y > maxBound__[1]:
            maxBound__[1] = y
        if z > maxBound__[2]:
            maxBound__[2] = z
        if (x,y) in heights:
            heights[(x,y)] = [min(z,heights[(x,y)][0]),max(z,heights[(x,y)][1])]
        else:
            heights[(x,y)] = [z,z]
    np.save(pfad+"/heights.npy", np.array(list(heights.keys())))
    np.save(pfad+"/heightsValues.npy", np.array(list(heights.values())))

    # -%%
    #for x_mid in range(int(maxBound__[0]-minBound__[0])//partSize):
    #    x_mid = x_mid*partSize+int(minBound__[0])+partSize//2
    #    for y_mid in range(int(maxBound__[1]-minBound__[1])//partSize):
    #        y_mid = y_mid*partSize+int(minBound__[1])+partSize//2
            #for z_mid in range(int(maxBound__[2]-minBound__[2])//partSize):
            #    z_mid = z_mid*partSize+int(minBound__[2])
            # we grab all z to have a bottom
    # -%%
    #x_mid = 134//6-2
    #y_mid = 155//6-3
    #for ttt2 in range(1):
    for x_mid in range(int(maxBound__[0]-minBound__[0])//partSize):
        #x_mid = x_mid*partSize+int(minBound__[0])+partSize//2
        #for ttt in range(1):
        for y_mid in range(int(maxBound__[1]-minBound__[1])//partSize):
            try:
                xy_done = np.load(pfad+"/xy_done.npy")
            except: xy_done = np.array([[-1,-1]])
            #if np.array([x_mid,y_mid]) in xy_done:
            #    continue
            y_mid = y_mid*partSize+int(minBound__[1])+partSize//2
            if True:
                print("Loading ",x_mid,y_mid)
                alreadyRefined = False
                points = None
                for x in range(-partSize//2+x_mid,partSize//2+x_mid):
                    for y in range(-partSize//2+y_mid,partSize//2+y_mid):
                        for z in range(int(minBound__[2]),int(maxBound__[2]+1)):
                            try:
                                if checkEmptyPoints(x,y,z):
                                    alreadyRefined = True
                                if alreadyRefined:
                                    continue
                                points_ = loadPoints(x,y,z)
                                if points_ is not None:
                                    try:
                                        points = np.concatenate([points,points_],0)
                                    except:
                                        points = points_
                            except: pass # no points to load here
                if points is not None:
                        pcd = o3d.geometry.PointCloud()
                        pcd.points = o3d.utility.Vector3dVector(points[:,:3])
                        pcd.colors = o3d.utility.Vector3dVector(points[:,3:])
                        cl, ind = pcd.remove_statistical_outlier(nb_neighbors=20,std_ratio=2.0)
                        cl, ind = cl.remove_radius_outlier(nb_points=2, radius=20.05)
                        if debug:
                            pass
                            #o3d.visualization.draw_geometries([cl])
                else:
                        continue
                if len(cl.points) == 0:
                    #no real points make all empty
                    for x in range(-partSize//2+x_mid,partSize//2+x_mid):
                        for y in range(-partSize//2+y_mid,partSize//2+y_mid):
                            for z in range(int(minBound__[2]),int(maxBound__[2]+1)):
                                points_ = loadPoints(x,y,z)
                                if points_ is not None:
                                    appendEmptyPoints(x,y,z, np.array([[x*35.,y*35.,z*35.]]))
                    continue
                if alreadyRefined:
                    continue
                voxelSize = 8.0
                rangemax = 1
                #create EmptyUP Voxels (5 iterations)
                voxel_grid = o3d.geometry.VoxelGrid.create_from_point_cloud(cl,
                                                                            voxel_size=voxelSize/2**(rangemax-1))
                o3d.visualization.draw_geometries([cl])