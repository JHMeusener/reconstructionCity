#!/usr/bin/env python
import logging
import matplotlib.pyplot as plt
import numpy as np
import open3d as o3d
import os
import subprocess
import torch
from PointCloudNNBoundswithNewEmptyPerRegionDebug import NeuralBound, reloadNeuralVolume, NeuralVolumeCellRegister, loadPoints, loadEmptyPoints
from scipy.spatial.transform import Rotation as R
from scipy.interpolate import griddata
from neuralVolumeHelper import SineLayer, matrixLookat, createInputVector_planeHitModel,HiddenPrints, SIREN, circular2sinCosC,bound2Mesh, compare2CenteredModels, bound2Pointcloud, meshIt, modelCenterCorrection, getPredictionPoints,compare2CenteredModels, bound2bounds, meshBoundsTM, mesh2pointcloud, array2Pointcloud
from PIL import Image

import constructCity_config

debug = constructCity_config.debug

pfad = constructCity_config.pfad
vhacdPath = constructCity_config.vhacdPath
partSize = constructCity_config.partSize


def train(points_normed, rgb):
    idx = np.arange(points_normed.shape[0])
    np.random.shuffle(idx)
    points_normed = points_normed[idx]
    rgb = rgb[idx]
    for chunk in range(0,len(points_normed),50000):
        points_normed_chunk = points_normed[chunk:chunk+50000]
        rgb_chunk = rgb[chunk:chunk+50000]
        points_normed_chunk = torch.tensor(points_normed_chunk).cuda().float()
        rgb_chunk = torch.tensor(rgb_chunk).cuda().float()
        lastLoss = 1.
        for i in range(5500):
            optim.zero_grad()
            out = learnModel(points_normed_chunk)*0.5+0.5
            loss = (out-rgb_chunk).abs().mean()
            lastLoss = loss.item()
            l2_lambda = 0.005
            l2_regularizer = sum(p.pow(2.0).sum()
                            for p in learnModel.parameters())
            loss = (loss + l2_lambda * l2_regularizer) * lastLoss
            loss.backward()
            optim.step()
            if lastLoss < 0.00001:
                break
        logging.info("loss of prediction: {}".format(lastLoss))#    print(lastLoss)

def predict(points_normed):
    orgShape = points_normed.shape
    points_normed = points_normed.reshape((-1,3))
    out = np.zeros_like(points_normed)
    for chunk in range(0,len(points_normed),50000):
        chunkTensor = torch.tensor(points_normed[chunk:chunk+50000]).cuda().float()
        with torch.no_grad():
            outchunk = learnModel(chunkTensor)*0.5+0.5
        out[chunk:chunk+50000] = outchunk.cpu().numpy()
    out = out.reshape(orgShape)
    return out

def mockPredict(points_normed):
    points = points_normed.reshape((-1,3))
    mask1 = ((points[:,0] > -2) & (points[:,0] < 1)) 
    mask2 = ((points[:,1] > -1) & (points[:,1] < 3))
    mask3 =    ((points[:,2] > -3) & (points[:,2] < 3)) 
    mask = (mask1|mask2)&mask3
    rgb = np.zeros((points.shape[0],3))
    rgb[mask] = np.array([1.,0,0])
    return rgb.reshape(points_normed.shape)



if __name__ == "__main__":
    with open(pfad+"/id.txt", 'r') as f:
        id = f.readline()
    # load all data
    points = np.load(pfad+"/partPointsColorLearning.npy")
    rgb = np.load(pfad+"/partPointsColorLearningColors.npy")

    siren = SIREN([3,12, 128, 128, 3], lastlayer=False)
    learnModel = torch.nn.Sequential(siren, SineLayer(3,3,scale=False,phaseShift=False,dynaPhaseShift=False, bias=False)).cuda()
    optim = torch.optim.Adam(learnModel.parameters(), lr=0.001)



    logging.info("reading mesh")
    mesh = o3d.io.read_triangle_mesh(pfad+"/meshing/bundle_mesh.ply")

    faces = np.asarray(mesh.triangles)
    vertices = np.asarray(mesh.vertices)

    verticesMid = np.mean(vertices, axis=0)
    verticesMin = np.min(vertices, axis=0)
    verticesMax = np.max(vertices, axis=0)
    vertices_normed = (vertices-verticesMid)/(verticesMax-verticesMin)*8.
    points_normed = (points-verticesMid)/(verticesMax-verticesMin)*8.

    squares = len(faces)//2+1 if len(faces)%2 == 1 else  len(faces)//2 
    size = 20

    maxSize = 50000

    v_value = squares*(size+1)
    u_value = size
    loops = []
    endVertices = []
    stepSize = 1./squares
    '''for i in range(len(faces)//2):
        loops.append([(i*(size+1)/(squares*(size+1)),1.),
                        (i*(size+1)/(squares*(size+1)),0.),
                        (min(1.,((i+1)*(size+1)/(squares*(size+1)))),1.)])
        loops.append([(((i*(size+1)))/(squares*(size+1)),0.),
                        (min(1.,((i+1)*(size+1))/(squares*(size+1))),1.),
                        ((min(1.,((i+1)*(size+1))/(squares*(size+1)))),0.)])
        endVertices.append(vertices[faces[i*2]])
        endVertices.append(vertices[faces[i*2+1]])

    if len(faces)%2 == 1:
        i = len(faces)//2+1
        loops.append([(i*(size+1)/(squares*(size+1)),1.),
                        (i*(size+1)/(squares*(size+1)),0.),
                        (min(1.,((i+1)*(size+1)/(squares*(size+1)))),1.)])
        endVertices.append(vertices[faces[-1]])'''
    for i in range(len(faces)//2):
        loops.append([((i*(size+1))/(squares*(size+1)),1.),
                        ((i*(size+1))/(squares*(size+1)),0.),
                        (min(1.,(((i+1)*(size+1)-1)/(squares*(size+1)))),1.)])
        loops.append([((((i*(size+1)))+1)/(squares*(size+1)),0.),
                        (min(1.,(((i+1)*(size+1)))/(squares*(size+1))),1.),
                        ((min(1.,(((i+1)*(size+1)))/(squares*(size+1)))),0.)])
        endVertices.append(vertices_normed[faces[i*2]])
        endVertices.append(vertices_normed[faces[i*2+1]])

    if len(faces)%2 == 1:
        i = len(faces)//2+1
        loops.append([((i*(size+1)+1)/(squares*(size+1)),1.),
                        ((i*(size+1)+1)/(squares*(size+1)),0.),
                        (min(1.,(((i+1)*(size+1)-1)/(squares*(size+1)))),1.)])
        endVertices.append(vertices_normed[faces[-1]])


    loops = np.array(loops).reshape((-1, 2))

    #create textureImage
    textureImage = np.zeros((u_value,v_value,3))

    # target grid to interpolate to
    logging.info("creating texturePositions")
    xi = np.arange(0,size+1,1)
    yi = np.arange(0,size,1)
    xi,yi = np.meshgrid(xi,yi)
    intuvs = np.array([[0,0], [size-1,0],[0,size-1]])
    intuvs2 = np.array([[size-1,1],[0,size-1+1],[size-1,size-1+1]])
    for square in range(squares):
        intcols = np.array(endVertices[square*2])
        # interpolate
        zi = griddata((intuvs[:,1],intuvs[:,0]), intcols ,(xi,yi),method='linear')
        zi = np.nan_to_num(zi, copy=True, nan=0, posinf=999999, neginf=-999999)
        #zi[zi < 0] = zi[zi < 0]/zi[zi < 0]-1
        intcols2 = np.array(endVertices[square*2+1])
        # interpolate
        zi2 = griddata((intuvs2[:,1],intuvs2[:,0]), intcols2 ,(xi,yi),method='linear')
        zi2 = np.nan_to_num(zi2, copy=True, nan=0, posinf=999999, neginf=-999999)
        #zi2[zi2 < 0] = zi2[zi2 < 0]/zi2[zi2 < 0]-1
        textureImage[0:size,(size+1)*square:(size+1)*(square+1),:] = zi
        textureImage[0:size,(size+1)*square:(size+1)*(square+1),:] += zi2
    #save grey image in case of out of memory errors
    im = Image.fromarray((textureImage*0+128).astype(np.uint8))
    im.save(pfad+"/meshing/texture.png")
    np.save(pfad+"/meshing/loops.npy",loops)

    #train the texture predictor
    logging.info("training Textureprediction")
    train(points_normed, rgb)
    logging.info("saving Texture")
    textureImage = predict(textureImage)*255.
    textureImage = np.nan_to_num(textureImage, copy=True, nan=0, posinf=255., neginf=0).astype(np.uint8)
    im = Image.fromarray(textureImage)
    im.save(pfad+"/meshing/texture.png")

