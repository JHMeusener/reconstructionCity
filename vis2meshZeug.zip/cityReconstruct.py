#!/usr/bin/env python
import os
import sys
import glob
import argparse
from os.path import join,dirname,abspath,exists,basename
import pathlib
import subprocess
import logging
import json
import re
import datetime
import shutil
import stat
import matplotlib.pyplot as plt
import numpy as np
import open3d as o3d
import trimesh as tm
import os
import pyntcloud
from pathlib import Path
import subprocess
import torch
from PointCloudNNBoundswithNewEmptyPerRegionDebug import NeuralBound, reloadNeuralVolume, NeuralVolumeCellRegister, loadPoints, loadEmptyPoints
from scipy.spatial.transform import Rotation as R
from inference import CreateCam, CreateTaskJson, RunProcess
import pandas as pd

debug = False

pfad = "/home/jhm/Desktop/Arbeit/ConvexNeuralVolume"
#pfad = "/files/Code/convexNeuralVolumeData"



def create_cloud(points, rgb):
    # create ply file
    points = np.concatenate((points, rgb*255), axis=1)
    #vertices = np.array(np.ndarray.tolist(points),
    #                 dtype=[('x', 'f4'), ('y', 'f4'),
    #                        ('z', 'f4'), ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')])
    d = {'x': points[:,0].astype(np.float),'y': points[:,1].astype(np.float),'z': points[:,2].astype(np.float), 
             'red' : points[:,3].astype(np.uint8), 'green' : points[:,4].astype(np.uint8), 'blue' : points[:,5].astype(np.uint8)}
    cld = pyntcloud.PyntCloud(pd.DataFrame(data=d))
    #cld = pyntcloud.PyntCloud(pd.DataFrame(data=vertices, columns =["x", "y", "z", "red", "green", "blue"]))
    cld.to_file(pfad+"/meshing/tmp_cloud.ply")

def RunTexturing(config, id):
    ## Run vvtool commands
    with open(pfad+"/meshing/id.txt", 'w') as f:
        f.write("{}".format(id))
    p = subprocess.Popen(['python','createBlenderUVMap.py'] , stdout=subprocess.PIPE)
    outs, errs = p.communicate()
    p = subprocess.Popen("blender -b --python blenderScript.py", shell=True, stdout=subprocess.PIPE)
    outs, errs = p.communicate()
    #p = subprocess.Popen(["TextureMesh",config['SUBDIR_FOLDER']+"/bundle_mesh.mva"],stdout=subprocess.PIPE)
    #outs, errs = p.communicate()
    return config

def CopyResult(config,neuralVolume, pfad):
    if exists(config['SUBDIR_FOLDER']+"/bundle_mesh_texture.ply"):
        print("*************** ")
        print("*** Success *** ")
        print()
        #os.chmod(result_file, stat.S_IROTH|stat.S_IWOTH|stat.S_IXOTH)
        result_copy_file = config['SUBDIR_FOLDER']+"/bundle_mesh_texture.ply"
        shutil.copy(result_copy_file, pfad+"/textured/{}.ply".format(neuralVolume.id))
        result_copy_file = config['SUBDIR_FOLDER']+"/bundle_mesh_texture.png"
        shutil.copy(result_copy_file, pfad+"/textured/{}.png".format(neuralVolume.id))
    else:
        print("*** Generation Failed *** ")


def createViews(emptyPoints):
    views = []
    #get lower empty points
    z_min = emptyPoints[:,2].min()
    for ep in emptyPoints:
        if ep[2] < z_min+12.0:
            #height might be okay, now create views in every direction
            for phi in range(-30,90,30):
                for theta in range(0,360,30):
                    view = {"width": 512,
                            "height": 512,
                            "K":[[150, 0, 128], [0, 150, 128], [0, 0, 1]]}
                    r = R.from_euler('xyz', [phi,theta,0.], degrees=True).as_matrix()
                    view["R"] = r.tolist()
                    view["C"] = ep.tolist()
                    views.append(view)
    return {"imgs":views}


def tempSetup():
    os.environ["PATH"] += os.pathsep + "/home/jhm/vis2mesh/tools/bin"
    os.environ["PATH"] += os.pathsep + "/home/jhm/vis2mesh/tools/bin/OpenMVS"
    os.environ["PATH"] += os.pathsep + "/home/jhm/Documents/blender/blender2.80/blender-2.80-linux-glibc217-x86_64"
    os.environ["LD_LIBRARY_PATH"] += os.pathsep +  "/home/jhm/vis2mesh/tools/lib/OpenMVS"
    os.environ["LD_LIBRARY_PATH"] += os.pathsep +  "/home/jhm/vis2mesh/tools/lib"
    Toolset = {'vvtool': 'vvtool', 'o3d_vvcreator.py': 'o3d_vvcreator.py', 'ReconstructMesh': 'ReconstructMesh'}
    ########
    ## Config IO
    ########
    INPUT_CLOUD = os.path.abspath(pfad+"/meshing/tmp_cloud.ply")
    

    WORK_FOLDER = os.path.abspath(pfad+"/meshing/tmp_work")
    OUTPUT_FOLDER = os.path.abspath(pfad+"/meshing/tmp_output")
    SUBDIR_FOLDER = os.path.abspath(pfad+"/meshing/tmp_subdir")
    RENDER_FOLDER = os.path.abspath(pfad+"/meshing/tmp_render")
    VISCONF_FOLDER = os.path.abspath(pfad+"/meshing/tmp_viconf")
    pathlib.Path(WORK_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(SUBDIR_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(RENDER_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(VISCONF_FOLDER).mkdir(parents=True, exist_ok=True)
    pathlib.Path(OUTPUT_FOLDER).mkdir(parents=True, exist_ok=True)
    # Clean Output and conf
    for c in glob.glob(join(OUTPUT_FOLDER,'*')):
        if os.path.isdir(c):
            shutil.rmtree(c)
        else:
            os.remove(c)
    for c in glob.glob(join(VISCONF_FOLDER,'*')):
        if os.path.isdir(c):
            shutil.rmtree(c)
        else:
            os.remove(c)

    for c in glob.glob(join(RENDER_FOLDER,'*')):
        if os.path.isdir(c):
            shutil.rmtree(c)
        else:
            os.remove(c)
    return {'INPUT_CLOUD': INPUT_CLOUD,
            'INPUT_CAM': pfad+"/meshing/tmp_views.json",
            'INPUT_MESH':'',
            'INPUT_TEXMESH': '',
            'INPUT_RGBMESH':'',
            'BASE_CAM':'',
            'CAM_NAME':'tempCam',
            'TOOLCHAIN':'NET.POINT_DELAY',
            'WORK_FOLDER': WORK_FOLDER,
            'SUBDIR_FOLDER': SUBDIR_FOLDER,
            'OUTPUT_FOLDER': OUTPUT_FOLDER,
            'RENDER_FOLDER': RENDER_FOLDER,
            'VISCONF_FOLDER': VISCONF_FOLDER,
            'Toolset': Toolset,
            'imagewidth':512,
            'imageheight':512,
            'imagefocal':300,
            # 'camgenheight':args.camgenheight,
            # 'camgenoverlap':args.camgenoverlap,
            'render_shader':'POINT',
            'render_radius_k':6,
            'vis':'NET',
            'vis_arch':"CascadeNet(['PartialConvUNet(input_channels=2)', 'PartialConvUNet(input_channels=2)', 'PartialConvUNet(input_channels=3)'])",
            'vis_checkpoint':'./checkpoints/VDVNet_CascadePPP_epoch30.pth',
            'vis_gt_tolerance': 0.05,
            'vis_conf_threshold':0.5,
            'recon_param': '-d 1'}

if __name__ == '__main__':

    logging.info("reading heights")
    heights = {}
    minBound__ = np.ones(3) * 9999999
    maxBound__ = np.ones(3) * 0
    for name in os.listdir(pfad+"/blocks"):
        x = int(name.split("x")[0])
        y = int(name.split("x")[1].split("y")[0])
        z = int(name.split("x")[1].split("y")[1].split("z")[0])
        if x < minBound__[0]:
            minBound__[0] = x
        if y < minBound__[1]:
            minBound__[1] = y
        if z < minBound__[2]:
            minBound__[2] = z
        if x > maxBound__[0]:
            maxBound__[0] = x
        if y > maxBound__[1]:
            maxBound__[1] = y
        if z > maxBound__[2]:
            maxBound__[2] = z
        if (x,y) in heights:
            heights[(x,y)] = [min(z,heights[(x,y)][0]),max(z,heights[(x,y)][1])]
        else:
            heights[(x,y)] = [z,z]
    np.save(pfad+"/heights.npy", np.array(list(heights.keys())))
    np.save(pfad+"/heightsValues.npy", np.array(list(heights.values())))

    # logname = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.log'
    logging.basicConfig(level = logging.INFO)

    times = 0

    cl = None
    pcd = None

    #only for the first time!
    if len(list(os.listdir(pfad+"/saveNeuralNetwork/")))==0:
        #load and register all neural volumes
        volList = os.listdir(pfad+"/neuralVolumes")
        for i,v in enumerate(volList):
            if i%100==0:
                print("initialize volume ",i," of ",len(volList))
            array = np.load(pfad+"/neuralVolumes/"+v)
            center = array[0]
            Hrep = array[1:]  
            newVolume = NeuralBound(torch.tensor(Hrep).cuda() ,center =torch.tensor(center).cuda())
            np.save(pfad+"/saveNeuralNetwork/{}".format(newVolume.id), torch.cat((newVolume.bounds,newVolume.center[None,:]),0).detach().cpu().numpy())
            #deregister Neural Volume
            NeuralBound.neuralBoundList[-1] = None
            del newVolume

    logging.info("creating Register")
    register = NeuralVolumeCellRegister()
    #register all cells but deactivate them afterwards
    for i in range(len(NeuralBound.neuralBoundList)):
        if i % 100 == 0:
            print("register cells ",i," of ",len(NeuralBound.neuralBoundList))
        reloadNeuralVolume(i,register)
        b = NeuralBound.neuralBoundList[i]
        if b is not None:
            cells = b.getCellBlocks()
            register.registerId(cells, b.id)
            b.deactivate()
            del b
    #extend neuralBoundList to max ID of saved neuralVolumes
    logging.info("extending neural Boundlist")
    maxid = 0
    for name in os.listdir(pfad+"/saveNeuralNetwork/"):
        tempid = int(name.split(".")[0])
        if tempid > maxid:
            maxid = tempid
    NeuralBound.neuralBoundList = [None]*maxid 
    ###############################################
    breakAll = False
    for i in range(len(NeuralBound.neuralBoundList)):
        
        #clear tempPath
        for c in glob.glob(join(pfad+"/meshing/",'*')):
            if os.path.isdir(c):
                shutil.rmtree(c)
            else:
                os.remove(c)
        logging.info("doing Volume {}".format(i))
        reloadNeuralVolume(i, register)
        b = NeuralBound.neuralBoundList[i]
        if b is not None:
            cells = b.getCellBlocks(distance=36.0)
        else: continue 
        #load points for the cells
        points = None 
        emptyPoints = None 
        for cell in cells:
            if points is None:
                points = loadPoints(cell[0],cell[1],cell[2])
            else:
                try:
                    points = np.concatenate((points,loadPoints(cell[0],cell[1],cell[2])),axis=0)
                except:
                    pass
            if emptyPoints is None:
                emptyPoints = loadEmptyPoints(cell[0],cell[1],cell[2])
            else:
                try:
                    emptyPoints = np.concatenate((emptyPoints,loadEmptyPoints(cell[0],cell[1],cell[2])),axis=0)
                except:
                    pass
        if points is None:
            continue 
        #filter points outside of the bounds and empty points inside of the bounds
        pointMask = b.filterPoints(torch.tensor(points[:,:3]).float().cuda(), torch.zeros(points[:,0].shape).type(torch.bool).cuda())
        if emptyPoints is not None:
            emptyMask = b.filterPoints(torch.tensor(emptyPoints).float().cuda(), torch.zeros(emptyPoints[:,0].shape).type(torch.bool).cuda())
        points = points[pointMask.cpu().numpy()]
        if emptyPoints is not None:
            emptyPoints = emptyPoints[~emptyMask.cpu().numpy()]
        if points is None:
            continue 
        if debug:
            pcd = o3d.geometry.PointCloud()
            pcd.points = o3d.utility.Vector3dVector(points[:,:3])
            pcd.colors = o3d.utility.Vector3dVector(points[:,3:])
            pcde = o3d.geometry.PointCloud()
            if emptyPoints is not None:
                pcde.points = o3d.utility.Vector3dVector(emptyPoints)
                colors = np.zeros_like(emptyPoints)
                colors[:,0] = 1
                pcde.colors = o3d.utility.Vector3dVector(colors)
            o3d.visualization.draw_geometries([pcd, pcde])    
        create_cloud(points[:,:3], points[:,3:])
        if emptyPoints is not None:
            views = createViews(emptyPoints)
        else:
            continue
        with open(pfad+"/meshing/tmp_views.json", "w") as f:
            json.dump(views, f, indent=3)
        #run mesh recreation from point cloud
        config = tempSetup()
        config = CreateCam(config)
        config =  CreateTaskJson(config)
        config =  RunProcess(config)
        #load mesh
        config = RunTexturing(config, b.id)
        b.deactivate()
        del b



    



#if __name__ == '__main__':
#    main()
