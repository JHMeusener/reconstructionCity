#!/usr/bin/env python
import os
import sys
import glob
import argparse
from os.path import join,dirname,abspath,exists,basename
import pathlib
import subprocess
import logging
import json
import re
import datetime
import shutil
import stat
import matplotlib.pyplot as plt
import numpy as np
from numpy.core.numeric import zeros_like
import open3d as o3d
import trimesh as tm
import os
import pyntcloud
from pathlib import Path
import subprocess
import torch
from PointCloudNNBoundswithNewEmptyPerRegionDebug import NeuralBound, reloadNeuralVolume, NeuralVolumeCellRegister, loadPoints, loadEmptyPoints
from scipy.spatial.transform import Rotation as R
from inference import CreateCam, CreateTaskJson, RunProcess
import pandas as pd


debug = False

pfad = "/home/jhm/Desktop/Arbeit/ConvexNeuralVolume"
#pfad = "/files/Code/convexNeuralVolumeData"


def create_cloud(points, rgb):
    # create ply file
    points = np.concatenate((points, rgb*255), axis=1)
    #vertices = np.array(np.ndarray.tolist(points),
    #                 dtype=[('x', 'f4'), ('y', 'f4'),
    #                        ('z', 'f4'), ('red', 'u1'), ('green', 'u1'), ('blue', 'u1')])
    d = {'x': points[:,0].astype(np.float),'y': points[:,1].astype(np.float),'z': points[:,2].astype(np.float), 
             'red' : points[:,3].astype(np.uint8), 'green' : points[:,4].astype(np.uint8), 'blue' : points[:,5].astype(np.uint8)}
    cld = pyntcloud.PyntCloud(pd.DataFrame(data=d))
    #cld = pyntcloud.PyntCloud(pd.DataFrame(data=vertices, columns =["x", "y", "z", "red", "green", "blue"]))
    cld.to_file(pfad+"/meshing/tmp_cloud.ply")

def RunTexturing(config, id):
    ## Run vvtool commands
    with open(pfad+"/meshing/id.txt", 'w') as f:
	    f.write("{}".format(id))
    p = subprocess.Popen(['python','createBlenderUVMap.py'] , stdout=subprocess.PIPE)
    outs, errs = p.communicate()
    p = subprocess.Popen("blender -b --python blenderScript.py", shell=True, stdout=subprocess.PIPE)
    outs, errs = p.communicate()
    #p = subprocess.Popen(["TextureMesh",config['SUBDIR_FOLDER']+"/bundle_mesh.mva"],stdout=subprocess.PIPE)
    #outs, errs = p.communicate()
    return config



def tempSetup():
    os.environ["PATH"] += os.pathsep + "/home/jhm/vis2mesh/tools/bin"
    os.environ["PATH"] += os.pathsep + "/home/jhm/vis2mesh/tools/bin/OpenMVS"
    os.environ["PATH"] += os.pathsep + "/home/jhm/Documents/blender/blender2.80/blender-2.80-linux-glibc217-x86_64"
    os.environ["LD_LIBRARY_PATH"] += os.pathsep +  "/home/jhm/vis2mesh/tools/lib/OpenMVS"
    os.environ["LD_LIBRARY_PATH"] += os.pathsep +  "/home/jhm/vis2mesh/tools/lib"
    Toolset = {'vvtool': 'vvtool', 'o3d_vvcreator.py': 'o3d_vvcreator.py', 'ReconstructMesh': 'ReconstructMesh'}
    ########
    ## Config IO
    ########

# logname = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.log'
logging.basicConfig(level = logging.INFO)

times = 0

cl = None
pcd = None
'''
cells = []
for x in range(9,15):
    for y in range(160,175):
        for z in range(0,100):
            cells.append([x,y,z])
#load points for the cells
points = None 
for cell in cells:
        if points is None:
            points = loadPoints(cell[0],cell[1],cell[2])
        else:
            try:
                points = np.concatenate((points,loadPoints(cell[0],cell[1],cell[2])),axis=0)
            except:
                pass
'''

#create a red plus in green background
xx = yy = zz = np.linspace(-5,5,20)
points = np.stack(np.meshgrid(xx,yy,zz),axis=-1).reshape((-1,3))
rgb = (np.random.rand(points.shape[0],3))
mask1 = ((points[:,0] > -1) & (points[:,0] < 1)) 
mask2 = ((points[:,1] > -1) & (points[:,1] < 1))
mask3 =    ((points[:,2] > -1) & (points[:,2] < 1)) 
mask = (mask1|mask2)&mask3
rgb[mask,0] = 1.

pcd = o3d.geometry.PointCloud()
pcd.points = o3d.utility.Vector3dVector(points)
pcd.colors = o3d.utility.Vector3dVector(rgb)
o3d.visualization.draw_geometries([pcd])

#save pointcloud
o3d.io.write_point_cloud(pfad+"/meshing/tmp_cloud.ply", pcd)
#create a mesh plane in blender fitting to the ply pointcloud
#save this mesh as pfad+ /meshing/tmp_subdir/bundle_mesh.ply
#load mesh
RunTexturing("eh", 0)

#view the mesh in blender

   


#def main():
#    config=Setup(parseArgs())
#    config=CreateCam(config)
#    config=CreateTaskJson(config)
#    config=RunProcess(config)
#    print('Process Done')


#if __name__ == '__main__':
#    main()
